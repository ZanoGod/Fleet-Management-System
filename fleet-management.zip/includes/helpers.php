<?php

declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function asset_url(string $path): string
{
    $normalizedPath = ltrim(str_replace('\\', '/', $path), '/');

    $absolutePath = dirname(__DIR__) . DIRECTORY_SEPARATOR
        . str_replace('/', DIRECTORY_SEPARATOR, $normalizedPath);

    $url = '/fleet-management/' . $normalizedPath;

    if (is_file($absolutePath)) {
        $url .= '?v=' . filemtime($absolutePath);
    }

    return $url;
}


function app_url(string $path = ''): string
{
    static $base = null;

    if ($base === null) {
        // e.g. /fleet-management/includes -> /fleet-management
        $base = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));

        if (str_ends_with($base, '/includes')) {
            $base = dirname($base);
        }

        $base = rtrim($base, '/');
    }

    return $base . '/' . ltrim($path, '/');
}



function redirect(string $path): never
{
    header('Location: ' . app_url($path));
    exit;
}



function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function get_flash(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return $flash;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf_token(?string $token): bool
{
    return is_string($token)
        && isset($_SESSION['csrf_token'])
        && is_string($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function old(array $source, string $key, string $default = ''): string
{
    return isset($source[$key]) ? trim((string) $source[$key]) : $default;
}

function format_display_date(?string $date): string
{
    if ($date === null || $date === '') {
        return '-';
    }

    $timestamp = strtotime($date);

    return $timestamp ? date('d M Y', $timestamp) : $date;
}

function format_compact_date_range(?string $startDate, ?string $endDate): string
{
    if (($startDate === null || $startDate === '') && ($endDate === null || $endDate === '')) {
        return '-';
    }

    $startTimestamp = $startDate !== null && $startDate !== '' ? strtotime($startDate) : false;
    $endTimestamp = $endDate !== null && $endDate !== '' ? strtotime($endDate) : false;

    if (!$startTimestamp || !$endTimestamp) {
        $parts = array_values(array_filter([
            format_display_date($startDate),
            format_display_date($endDate),
        ], static fn(string $value): bool => $value !== '-'));

        return $parts === [] ? '-' : implode(' - ', $parts);
    }

    if (date('Y-m-d', $startTimestamp) === date('Y-m-d', $endTimestamp)) {
        return date('d M Y', $startTimestamp);
    }

    if (date('Y-m', $startTimestamp) === date('Y-m', $endTimestamp)) {
        return date('d', $startTimestamp) . ' - ' . date('d M Y', $endTimestamp);
    }

    if (date('Y', $startTimestamp) === date('Y', $endTimestamp)) {
        return date('d M', $startTimestamp) . ' - ' . date('d M Y', $endTimestamp);
    }

    return date('d M Y', $startTimestamp) . ' - ' . date('d M Y', $endTimestamp);
}

function booking_assignment_statuses(): array
{
    return [
        'Pending',
        'Confirm',
    ];
}

function booking_statuses(): array
{
    return [
        'Pending',
        'Confirm',
        'Completed',
        'Cancelled',
    ];
}

function status_badge_class(string $status): string
{
    return match (strtolower($status)) {
        'confirm' => 'status-confirm',
        'completed' => 'status-completed',
        'cancelled' => 'status-cancelled',
        default => 'status-pending',
    };
}


function booking_even_odd_options(): array
{
    return [
        'Even',
        'Odd',
    ];
}


function car_statuses(): array
{
    return [
        'Available',
        'Assigned',
        'Maintenance',
        'Inactive',
    ];
}

function operator_statuses(): array
{
    return [
        'Active',
        'Inactive',
    ];
}

function driver_statuses(): array
{
    return [
        'Available',
        'Assigned',
        'Leave',
        'Inactive',
    ];
}

function monthly_contract_assignment_types(): array
{
    return [
        'Driver Only',
        'Vehicle Only',
        'Vehicle and Driver',
    ];
}

function monthly_contract_statuses(): array
{
    return [
        'Draft',
        'Active',
        'Expired',
        'Renewed',
        'Cancelled',
    ];
}

function monthly_contract_rental_statuses(): array
{
    return [
        'Including fuel',
        'Excluding fuel',
        'Car only',
        'Driver only',
    ];
}


function selected(mixed $actual, mixed $expected): string
{
    return (string) $actual === (string) $expected ? 'selected' : '';
}

function in_allowed_values(string $value, array $allowedValues): bool
{
    return in_array($value, $allowedValues, true);
}

function row_id_exists(array $rows, int $expectedId): bool
{
    foreach ($rows as $row) {
        if ((int) ($row['id'] ?? 0) === $expectedId) {
            return true;
        }
    }

    return false;
}

function find_row_by_id(array $rows, int $expectedId): ?array
{
    foreach ($rows as $row) {
        if ((int) ($row['id'] ?? 0) === $expectedId) {
            return $row;
        }
    }

    return null;
}

function app_navigation(): array
{
    return [
        [
            'key' => 'dashboard',
            'label' => 'Dashboard',
            'path' => 'index.php',
            'description' => 'Overview and quick stats',
            // 'icon' => 'DB',
            'icon' => '<i class="bi bi-grid-1x2-fill"></i>',
        ],
        [
            'key' => 'bookings',
            'label' => 'Bookings',
            'path' => 'bookings.php',
            'description' => 'Trip assignments',
            // 'icon' => 'BK',
            'icon' => '<i class="bi bi-calendar-check-fill"></i>',
        ],
        [
            'key' => 'cars',
            'label' => 'Cars / Vehicles',
            'path' => 'cars.php',
            'description' => 'Vehicle master data',
            //  'icon' => 'CR',
            'icon' => '<i class="bi bi-car-front-fill"></i>',
        ],
        [
            'key' => 'drivers',
            'label' => 'Drivers',
            'path' => 'drivers.php',
            'description' => 'Driver directory',
            // 'icon' => 'DR',
            'icon' => '<i class="bi bi-person-vcard-fill"></i>',
        ],
        [
            'key' => 'operators',
            'label' => 'Operators',
            'path' => 'operators.php',
            'description' => 'Operator directory',
            // 'icon' => 'OP',
            'icon' => '<i class="bi bi-headset"></i>',
        ],
        [
            'key' => 'reports',
            'label' => 'Reports',
            'path' => 'reports.php',
            'description' => 'Status and planning',
            //'icon' => 'RP',
            'icon' => '<i class="bi bi-bar-chart-fill"></i>',
        ],
    ];
}

function monthly_contract_navigation(): array
{
    return [
        [
            'key' => 'monthly-contract-dashboard',
            'label' => 'Dashboard',
            'path' => 'monthly-contracts.php',
            'icon' => '<i class="bi bi-grid-1x2-fill"></i>',
        ],
        [
            'key' => 'contract-cars',
            'label' => 'Vehicles',
            'path' => 'contract_cars.php',
            'icon' => '<i class="bi bi-car-front-fill"></i>',
        ],
        [
            'key' => 'monthly-drivers',
            'label' => 'Drivers',
            'path' => 'drivers.php',
            'icon' => '<i class="bi bi-person-vcard-fill"></i>',
        ],
        [
            'key' => 'monthly-customers',
            'label' => 'Customers',
            'path' => 'customers.php',
            'icon' => '<span class="material-symbols-outlined">groups_2</span>',
        ],
        [
            'key' => 'monthly-operators',
            'label' => 'Operators',
            'path' => 'contract_operators.php',
            'icon' => '<i class="bi bi-headset"></i>',
        ],
        [
            'key' => 'monthly-reports',
            'label' => 'Reports',
            'path' => 'contract-reports.php',
            'icon' => '<i class="bi bi-bar-chart-fill"></i>',
        ],
    ];
}
function nav_is_active(string $activePage, string $expected): string
{
    return $activePage === $expected ? 'is-active' : '';
}

function vehicle_status_class(string $status): string
{
    return match (strtolower($status)) {
        'available' => 'resource-available',
        'assigned' => 'resource-assigned',
        'maintenance' => 'resource-maintenance',
        default => 'resource-inactive',
    };
}

function driver_status_class(string $status): string
{
    return match (strtolower($status)) {
        'available' => 'resource-available',
        'assigned', 'on trip' => 'resource-assigned',
        'leave' => 'resource-maintenance',
        default => 'resource-inactive',
    };
}

function operator_status_class(string $status): string
{
    return match (strtolower($status)) {
        'active' => 'resource-available',
        default => 'resource-inactive',
    };
}

function monthly_contract_status_badge_class(string $status): string
{
    return match (strtolower($status)) {
        'active' => 'status-confirm',
        'expired' => 'status-pending',
        'renewed' => 'status-completed',
        'cancelled' => 'status-cancelled',
        default => 'resource-maintenance',
    };
}

function monthly_contract_rental_badge_class(string $status): string {
    return match (trim($status)) {
        'Including fuel'         => 'rental-success',
        'Excluding fuel'          => 'rental-pending',
        'Driver only'            => 'rental-info',
        default                  => 'rental-default',
    };
}

function monthly_contract_assignment_badge_class(string $assignmentType): string
{
    return match (strtolower($assignmentType)) {
        'vehicle and driver' => 'resource-assigned',
        'vehicle only' => 'resource-available',
        default => 'resource-maintenance',
    };
}

function monthly_contract_money(mixed $amount): string
{
    return number_format((float) $amount, 0);
}

function monthly_contract_vehicle_display(array $contract): string
{
    $parts = array_values(array_filter([
        trim((string) ($contract['car_type'] ?? '')),
        trim((string) ($contract['plate_no'] ?? '')),
        trim((string) ($contract['model_name'] ?? '')),
    ], static fn(?string $value): bool => $value !== null && $value !== ''));

    return $parts === [] ? '-' : implode(' | ', $parts);
}

function monthly_contract_driver_display(array $contract): string
{
    $driverName = trim((string) ($contract['driver_name'] ?? ''));

    return $driverName !== '' ? $driverName : '-';
}

function monthly_contract_operator_display(array $contract): string
{
    $operatorName = trim((string) ($contract['operator_full_name'] ?? $contract['operator_name'] ?? ''));

    return $operatorName !== '' ? $operatorName : '-';
}

function monthly_contract_expiry_state(array $contract): string
{
    $status = strtolower((string) ($contract['status'] ?? ''));
    $endDate = trim((string) ($contract['end_date'] ?? ''));

    if ($endDate === '' || in_array($status, ['renewed', 'cancelled'], true)) {
        return 'normal';
    }

    $today = new DateTimeImmutable('today');
    $end = DateTimeImmutable::createFromFormat('Y-m-d', $endDate);

    if (!$end instanceof DateTimeImmutable) {
        return 'normal';
    }

    if ($end < $today) {
        return 'expired';
    }

    if ($end <= $today->modify('+30 days')) {
        return 'expiring';
    }

    return 'normal';
}


function fetch_cars_for_select(mysqli $db, bool $availableOnly = false): array
{
    $cars = [];
    $sql = 'SELECT id, car_type, plate_no, model_name, availability_status FROM cars';

    // If we only want available cars, append the WHERE clause
    if ($availableOnly) {
        $sql .= " WHERE availability_status = 'Available'";
    }

    $sql .= ' ORDER BY car_type ASC, plate_no ASC';

    $result = $db->query($sql);

    if ($result instanceof mysqli_result) {
        while ($row = $result->fetch_assoc()) {
            $cars[] = $row;
        }
    }

    return $cars;
}

function fetch_drivers_for_select(mysqli $db): array
{
    $drivers = [];
    $result = $db->query(
        'SELECT id, full_name, phone_number, driver_status
         FROM drivers
         ORDER BY full_name ASC'
    );

    if ($result instanceof mysqli_result) {
        while ($row = $result->fetch_assoc()) {
            $drivers[] = $row;
        }
    }

    return $drivers;
}

function fetch_monthly_cars_for_select(
    mysqli $db,
    bool $availableOnly = false,
    ?int $includeCarId = null
): array {
    $cars = [];
    $sql = 'SELECT c.id, c.car_type, c.plate_no, c.model_name, c.availability_status FROM monthly_cars AS c';
    $types = '';
    $params = [];

    if ($availableOnly) {
        $availableCondition = "c.availability_status = 'Available'
            AND NOT EXISTS (
                SELECT 1
                FROM monthly_contracts AS mc
                WHERE mc.car_id = c.id
                  AND mc.status IN ('Draft', 'Active')
            )";

        if ($includeCarId !== null && $includeCarId > 0) {
            $sql .= ' WHERE (' . $availableCondition . ' OR c.id = ?)';
            $types = 'i';
            $params[] = $includeCarId;
        } else {
            $sql .= ' WHERE ' . $availableCondition;
        }
    }

    $sql .= ' ORDER BY c.car_type ASC, c.plate_no ASC';
    $statement = $db->prepare($sql);

    if (!$statement instanceof mysqli_stmt) {
        return $cars;
    }

    if ($params !== []) {
        bind_statement_params($statement, $types, $params);
    }

    $statement->execute();
    $result = $statement->get_result();

    while ($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }

    $statement->close();

    return $cars;
}

function fetch_monthly_drivers_for_select(mysqli $db): array
{
    $drivers = [];
    $result = $db->query(
        'SELECT id, full_name, phone_number, driver_status
         FROM monthly_drivers
         ORDER BY full_name ASC'
    );

    if ($result instanceof mysqli_result) {
        while ($row = $result->fetch_assoc()) {
            $drivers[] = $row;
        }
    }

    return $drivers;
}

function fetch_monthly_contract_resource_assignments(mysqli $db, string $resourceColumn): array
{
    if (!in_array($resourceColumn, ['car_id', 'driver_id'], true)) {
        return [];
    }

    $assignments = [];
    $sql = "SELECT
                {$resourceColumn} AS resource_id,
                contract_no,
                customer_name,
                start_date,
                end_date
            FROM monthly_contracts
            WHERE {$resourceColumn} IS NOT NULL
              AND status IN ('Draft', 'Active')
            ORDER BY start_date ASC, end_date ASC, id ASC";
    $result = $db->query($sql);

    if (!$result instanceof mysqli_result) {
        return [];
    }

    while ($row = $result->fetch_assoc()) {
        $resourceId = (int) ($row['resource_id'] ?? 0);

        if ($resourceId <= 0) {
            continue;
        }

        unset($row['resource_id']);
        $assignments[$resourceId][] = $row;
    }

    return $assignments;
}

function fetch_operators_for_select(mysqli $db, bool $activeOnly = false): array
{
    $operators = [];
    $sql = 'SELECT id, full_name, phone_number, operator_status
            FROM operators';

    if ($activeOnly) {
        $sql .= " WHERE operator_status = 'Active'";
    }

    $sql .= ' ORDER BY full_name ASC';
    $result = $db->query($sql);

    if ($result instanceof mysqli_result) {
        while ($row = $result->fetch_assoc()) {
            $operators[] = $row;
        }
    }

    return $operators;
}

function fetch_resource_booking_assignments(mysqli $db, string $resourceColumn): array
{
    if (!in_array($resourceColumn, ['car_id', 'driver_id'], true)) {
        return [];
    }

    $assignments = [];
    $statuses = booking_assignment_statuses();
    $placeholders = implode(', ', array_fill(0, count($statuses), '?'));
    $sql = "SELECT
                {$resourceColumn} AS resource_id,
                guest_company_name,
                start_date,
                end_date
            FROM bookings
            WHERE {$resourceColumn} IS NOT NULL
              AND status IN ({$placeholders})
            ORDER BY start_date ASC, end_date ASC, id ASC";

    $statement = $db->prepare($sql);

    if (!$statement instanceof mysqli_stmt) {
        return [];
    }

    bind_statement_params($statement, str_repeat('s', count($statuses)), $statuses);
    $statement->execute();
    $result = $statement->get_result();

    while ($row = $result->fetch_assoc()) {
        $resourceId = (int) ($row['resource_id'] ?? 0);

        if ($resourceId <= 0) {
            continue;
        }

        unset($row['resource_id']);
        $assignments[$resourceId][] = $row;
    }

    $statement->close();

    return $assignments;
}

function fetch_active_booking_resources(mysqli $db, ?int $excludeBookingId = null): array
{
    $activeBookings = [];
    $statuses = booking_assignment_statuses();
    $placeholders = implode(', ', array_fill(0, count($statuses), '?'));
    $sql = "SELECT
                id,
                car_id,
                secondary_car_id,
                driver_id,
                start_date,
                end_date
            FROM bookings
            WHERE status IN ({$placeholders})";

    if ($excludeBookingId !== null) {
        $sql .= ' AND id != ?';
    }

    $sql .= ' ORDER BY start_date ASC, end_date ASC, id ASC';

    $statement = $db->prepare($sql);

    if (!$statement instanceof mysqli_stmt) {
        return $activeBookings;
    }

    $types = str_repeat('s', count($statuses));
    $params = $statuses;

    if ($excludeBookingId !== null) {
        $types .= 'i';
        $params[] = $excludeBookingId;
    }

    bind_statement_params($statement, $types, $params);
    $statement->execute();
    $result = $statement->get_result();

    while ($row = $result->fetch_assoc()) {
        $activeBookings[] = $row;
    }

    $statement->close();

    return $activeBookings;
}

function booking_car_label(
    ?string $carType,
    ?string $plateNo = null,
    ?string $customCarName = null
): string {
    $customName = trim((string) $customCarName);

    if ($customName !== '') {
        return $customName;
    }

    $parts = array_values(array_filter([
        trim((string) $carType),
        trim((string) $plateNo),
    ], static fn(?string $value): bool => $value !== null && $value !== ''));

    return $parts === [] ? '-' : implode(' | ', $parts);
}

function booking_car_entries(array $booking): array
{
    $entries = [];

    $primaryCar = booking_car_label(
        $booking['car_type'] ?? null,
        $booking['plate_no'] ?? null,
        $booking['custom_car_name'] ?? null
    );

    if ($primaryCar !== '-') {
        $entries[] = $primaryCar;
    }

    $secondaryCar = booking_car_label(
        $booking['secondary_car_type'] ?? null,
        $booking['secondary_plate_no'] ?? null
    );

    if ($secondaryCar !== '-') {
        $entries[] = $secondaryCar;
    }

    return $entries === [] ? ['-'] : $entries;
}

function booking_car_display(array $booking): string
{
    return implode(' / ', booking_car_entries($booking));
}

function booking_driver_display(array $booking): string
{
    $customDriverName = trim((string) ($booking['custom_driver_name'] ?? ''));

    if ($customDriverName !== '') {
        return $customDriverName;
    }

    $driverName = trim((string) ($booking['driver_name'] ?? ''));

    return $driverName !== '' ? $driverName : '-';
}

function booking_operator_display(array $booking): string
{
    $operatorName = trim((string) ($booking['operator_full_name'] ?? $booking['operator_name'] ?? ''));

    return $operatorName !== '' ? $operatorName : '-';
}

function bind_statement_params(mysqli_stmt $statement, string $types, array $values): void
{
    $references = [$types];

    foreach ($values as $key => $value) {
        $references[] = &$values[$key];
    }

    $statement->bind_param(...$references);
}
